﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace subjScore_nehs_sh
{
    public class newSubj
    {
        public string SubjectName { get; set; }

        public List<string> NameList = new List<string>();


        public int? Level { get; set; }

        /// <summary>
        /// 必選修 True
        /// </summary>
        public bool req { get; set; }

        /// <summary>
        /// 校部訂
        /// </summary>
        public string reqBy { get; set; }
    }
}
