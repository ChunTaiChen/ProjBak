﻿using FISCA.Presentation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SHSchool.Data;
using System.IO;
using Aspose.Cells;

namespace subjScore_nehs_sh
{
    public class Program
    {
        [FISCA.MainMethod()]
        public static void Main()
        {
             RibbonBarItem rbRptItemABNew = MotherForm.RibbonBarItems["學生", "工具"];
            rbRptItemABNew["工具"]["合併科目成績"].Enable = true;
            rbRptItemABNew["工具"]["合併科目成績"].Click += delegate
            {
                Form1 f1 = new Form1();
                f1.ShowDialog();
            };
        
        }
    }
}
