﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using SHSchool.Data;
using System.IO;
using Aspose.Cells;

namespace subjScore_nehs_sh
{
    public partial class Form1 : FISCA.Presentation.Controls.BaseForm
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            iptGradeYear.Value = 3;
            iptSchoolYear.Value = int.Parse(K12.Data.School.DefaultSchoolYear);
            iptSemester.Value = int.Parse(K12.Data.School.DefaultSemester);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            btnRun.Enabled = false;
            // 讀取合併規則來源 Excel
            Workbook wb = new Workbook(new MemoryStream(Properties.Resources.實驗中學高中部科目修改));
            Worksheet wst = wb.Worksheets[0];
            // 建立合併
            List<newSubj> newSubjList = new List<newSubj>();
            for (int row = 1; row <= wst.Cells.MaxDataRow; row++)
            {
                if (wst.Cells[row, 0].StringValue.Trim() != "")
                {
                    newSubj ns = new newSubj();
                    ns.SubjectName = wst.Cells[row, 1].StringValue;
                    string[] words = wst.Cells[row, 0].StringValue.Split(new Char[] { ',' });
                    ns.NameList = words.ToList();
                    if (wst.Cells[row, 2].StringValue != "")
                    {
                        ns.Level = int.Parse(wst.Cells[row, 2].StringValue);
                    }
                    else
                        ns.Level = null;

                    if (wst.Cells[row, 3].StringValue == "必修")
                        ns.req = true;
                    else
                        ns.req = false;

                    ns.reqBy = wst.Cells[row, 4].StringValue;

                    newSubjList.Add(ns);
                }
            }


            // 讀取所選學生學期科目成績 103學年度第1學期,3年級
            List<string> StudentIDList = K12.Presentation.NLDPanels.Student.SelectedSource;
            List<SHSemesterScoreRecord> shScoreList = SHSemesterScore.SelectByStudentIDs(StudentIDList);

            List<SHSemesterScoreRecord> updateRecord = new List<SHSemesterScoreRecord>();

            foreach (SHSemesterScoreRecord rec in shScoreList)
            {
                if (rec.SchoolYear == iptSchoolYear.Value && rec.Semester == iptSemester.Value && rec.GradeYear == iptGradeYear.Value)
                {
                    // 取得新增科目
                   // List<SHSubjectScore> ssScore = new List<SHSubjectScore>();
                    List<SHSubjectScore> chkScore = new List<SHSubjectScore>();
                    foreach (newSubj ns in newSubjList)
                    {
                        chkScore.Clear();
                        foreach (string str in ns.NameList)
                        {
                            if (rec.Subjects.ContainsKey(str))
                            {
                                chkScore.Add(rec.Subjects[str]);
                            }
                        }

                        // 3科合併
                        if (chkScore.Count == 3 && chkScore[1] != null && chkScore[2] != null)
                        {
                            if (chkScore[0].Score.Value == chkScore[1].Score.Value && chkScore[1].Score.Value == chkScore[2].Score.Value)
                            {
                                SHSubjectScore newScore = chkScore[0];
                                newScore.Credit = chkScore[0].Credit + chkScore[1].Credit + chkScore[2].Credit;
                                // 將舊得移除
                                rec.Subjects.Remove(chkScore[0].Subject);
                                rec.Subjects.Remove(chkScore[1].Subject);
                                rec.Subjects.Remove(chkScore[2].Subject);

                                newScore.Subject = ns.SubjectName;
                                newScore.Required = ns.req;
                                newScore.RequiredBy = ns.reqBy;

                                rec.Subjects.Add(newScore.Subject, newScore);
                            }
                        }


                        // 2科合併
                        if (chkScore.Count == 2 && chkScore[1] != null)
                        {
                            if (chkScore[0].Score.Value == chkScore[1].Score.Value)
                            {
                                SHSubjectScore newScore = chkScore[0];
                                newScore.Credit = chkScore[0].Credit + chkScore[1].Credit;
                                // 將舊得移除
                                rec.Subjects.Remove(chkScore[0].Subject);
                                rec.Subjects.Remove(chkScore[1].Subject);
                                
                                newScore.Subject = ns.SubjectName;
                                newScore.Required = ns.req;
                                newScore.RequiredBy = ns.reqBy;

                                rec.Subjects.Add(newScore.Subject, newScore);
                            }
                        }

                        // 單科改名
                        if (chkScore.Count == 1)
                        {
                            SHSubjectScore newScore = chkScore[0];
                            // 將舊得移除
                            rec.Subjects.Remove(chkScore[0].Subject);
                            newScore.Subject = ns.SubjectName;
                            rec.Subjects.Add(newScore.Subject, newScore);
                        }
                    }          

                    
                    updateRecord.Add(rec);
                }              
            }

            if (updateRecord.Count > 0)
            {
                SHSemesterScore.Update(updateRecord);
            }

            // 解析資料並處理


            FISCA.Presentation.Controls.MsgBox.Show("完成!");
            btnRun.Enabled = true;
        }
    }
}
